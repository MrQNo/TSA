To use TSA for Tournaments of your own, you have to add 3 files in src/main/resources/token.txt (relative to jar):
1. Edit all files in conf/, copy them to your root directory (where the jar is) and remove the .template part of their names.
2. Create Timer for executing the jar, ready :-) (java -jar /path/to/TSA.jar)
